demo.state7 = function(){};
demo.state7.prototype = {
    preload: function(){},
    create: function(){
        game.stage.backgroundColor = '#777777';

        addChangeStateEventLister();
    },
    update: function(){}
};