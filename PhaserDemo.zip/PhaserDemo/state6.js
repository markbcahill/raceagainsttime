demo.state6 = function(){};
demo.state6.prototype = {
    preload: function(){},
    create: function(){
        game.stage.backgroundColor = '#666666';

        addChangeStateEventLister();
    },
    update: function(){}
};