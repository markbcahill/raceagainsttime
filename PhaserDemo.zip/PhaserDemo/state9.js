demo.state9 = function(){};
demo.state9.prototype = {
    preload: function(){},
    create: function(){
        game.stage.backgroundColor = '#999999';

        addChangeStateEventLister();
    },
    update: function(){}
};